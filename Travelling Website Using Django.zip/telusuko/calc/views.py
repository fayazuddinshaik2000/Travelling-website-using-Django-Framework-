from django.shortcuts import render
from django.http import HttpResponse

def home(request):
    return render(request,'hello.html',{'name':'fayaz'})
def add(request):
    val1=int(request.POST["num1"])
    val2=int(request.POST["num2"])
    val=val1+val2
    return render(request,'result.html',{'res':val})