from django.db import models
#python manage.py makemigrations
#python manage.py sqlmigrate travello 0001
#python manage.py migrate
# Create your models here.
class Destination(models.Model):
    name = models.CharField(max_length=100)
    price = models.IntegerField(0)
    img = models.ImageField(upload_to='pics')
    desc = models.TextField()
    offer = models.BooleanField(default=False)
    