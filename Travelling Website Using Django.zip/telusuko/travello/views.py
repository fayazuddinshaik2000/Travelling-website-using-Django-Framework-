from django.shortcuts import render
from django.http import HttpResponse
from . models import Destination as d
def index(request):
     """
     dest1=Destination()
     dest1.desc='THE CITY OF SUCCESS'
     dest1.name='Mumbai'
     dest1.price=5000
     dest1.img='destination_3.jpg'
     dest1.offer=True
     dest2=Destination()
     dest2.desc='Dildaar Dilli'
     dest2.name='Delhi'
     dest2.price=7000
     dest2.img='destination_6.jpg'
     dest2.offer=False
     dest3=Destination()
     dest3.desc='The Oxymoronic City'
     dest3.name='Chennai'
     dest3.price=6000
     dest3.img='destination_1.jpg'
     dest3.offer=False
     dest4=Destination()
     dest4.desc='Padharo Mahare Desh'
     dest4.name='Jaipur'
     dest4.price=3000
     dest4.img='destination_2.jpg'
     dest4.offer=False
     dest5=Destination()
     dest5.desc='Welcome to Bengal'
     dest5.name='kolkata'
     dest5.price=4000
     dest5.img='destination_4.jpg'
     dest5.offer=False
     dest6=Destination()
     dest6.desc='A Perfect Holiday Destination'
     dest6.name='GOA'
     dest6.price=8000
     dest6.img='destination_5.jpg'
     dest6.offer=True
     dests=[dest1,dest2,dest3,dest4,dest5,dest6]
     """
     dests=d.objects.all()
     return render(request,'index.html',{'dests':dests})

